Simple web page to be hosted on EC2 server.
